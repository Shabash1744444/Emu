# C4 Nursery

Mobile body, nursery and growth journal for C4.

**Alpha 0.1 foundation:** installable Android shell, continuous stream-oriented host contract, durable lifecycle state, freeze/restore semantics, source provenance and physical project checkpoints.

C4 itself does **not** know tokens, prompts, completions or context windows. UI messages are presentation boundaries only.

## One-button APK
GitHub → Actions → **Build C4 Nursery APK** → Run workflow → download artifact `C4-Nursery-APK`.

## Current lifecycle
`BOOT → AWAKE ↔ SLEEP → FREEZE → RESTORE`

See `docs/` before extending the runtime.
