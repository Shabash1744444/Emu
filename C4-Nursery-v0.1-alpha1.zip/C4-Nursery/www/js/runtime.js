const KEY='c4.nursery.state.v1';
const initial=()=>({version:1,mode:'AWAKE',eventSeq:0,sourceSeq:0,activeSource:null,events:[],lastCheckpoint:null,createdAt:Date.now()});
export class NurseryRuntime{
  constructor(storage=localStorage){this.storage=storage;this.state=this.restore();this.listeners=new Set()}
  restore(){try{const x=JSON.parse(this.storage.getItem(KEY));return x&&x.version===1?x:initial()}catch{return initial()}}
  on(fn){this.listeners.add(fn);return()=>this.listeners.delete(fn)}
  emit(type,payload={}){for(const fn of this.listeners)fn({type,payload,state:this.snapshot()})}
  snapshot(){return structuredClone(this.state)}
  persist(){this.storage.setItem(KEY,JSON.stringify(this.state))}
  checkpoint(reason){this.state.lastCheckpoint={at:Date.now(),reason,eventSeq:this.state.eventSeq};this.persist();this.emit('checkpoint',this.state.lastCheckpoint)}
  setMode(mode){if(!['AWAKE','SLEEP','FROZEN'].includes(mode))throw Error('bad mode');if(this.state.mode==='FROZEN'&&mode!=='AWAKE')return false;if(mode==='FROZEN'){this.checkpoint('pre-freeze');this.state.mode='FROZEN';this.persist();this.emit('mode',{mode});return true}this.state.mode=mode;this.persist();this.emit('mode',{mode});return true}
  openTextSource(){if(this.state.mode==='FROZEN')return null;if(this.state.activeSource)return this.state.activeSource.id;const id=`human-text-${++this.state.sourceSeq}`;this.state.activeSource={id,kind:'human-text',cursor:0,openedAt:Date.now()};this.persist();this.emit('source-open',this.state.activeSource);return id}
  ingestText(fragment,{boundary=false,sourceId=null}={}){if(this.state.mode==='FROZEN')return {accepted:false,reason:'frozen'};if(!fragment&&!boundary)return {accepted:false,reason:'empty'};const activeId=this.openTextSource();const sid=sourceId||activeId;const source=this.state.activeSource;if(sourceId&&source.id!==sourceId)return {accepted:false,reason:'source-mismatch'};const event={seq:++this.state.eventSeq,type:'HumanTextFragment',sourceId:sid,cursorStart:source.cursor,cursorEnd:source.cursor+fragment.length,text:fragment,boundaryHint:boundary,at:Date.now()};source.cursor=event.cursorEnd;this.state.events.push(event);if(this.state.events.length>500)this.state.events.splice(0,this.state.events.length-500);this.persist();this.emit('event',event);if(boundary){this.emit('boundary',{sourceId:sid,cursor:source.cursor})}return {accepted:true,event}}
  closeSource(){if(this.state.mode==='FROZEN'||!this.state.activeSource)return false;const s=this.state.activeSource;this.state.activeSource=null;this.persist();this.emit('source-close',s);return true}
}
