import {NurseryRuntime} from './runtime.js';
const rt=new NurseryRuntime();
const $=s=>document.querySelector(s), stream=$('#stream'), input=$('#input'), status=$('#status'), orb=$('#orb'), frozen=$('#frozen'), counter=$('#counter');
function haptic(){try{navigator.vibrate?.(12);window.Capacitor?.Plugins?.Haptics?.impact?.({style:'LIGHT'})}catch{}}
function add(text,kind='system',meta='RUNTIME'){const d=document.createElement('div');d.className=`card ${kind}`;const m=document.createElement('div');m.className='meta';m.textContent=meta;const b=document.createElement('div');b.textContent=text;d.append(m,b);stream.append(d);stream.scrollTop=stream.scrollHeight}
function paint(){const s=rt.snapshot();status.textContent=s.mode==='AWAKE'?'AWAKE · STREAM OPEN':s.mode==='SLEEP'?'SLEEP · CONSOLIDATION SHELL':'FROZEN · STATE SEALED';orb.className='orb '+(s.mode==='SLEEP'?'sleep':s.mode==='FROZEN'?'frozen':'');frozen.classList.toggle('show',s.mode==='FROZEN');document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===s.mode));counter.textContent=`${s.eventSeq} events`;input.disabled=s.mode==='FROZEN';$('#send').disabled=s.mode==='FROZEN'}
rt.on(({type,payload})=>{if(type==='mode')add(payload.mode==='FROZEN'?'Checkpoint committed. Runtime mutation locked.':`Mode → ${payload.mode}`);paint()});
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{haptic();const target=b.dataset.mode;if(rt.snapshot().mode==='FROZEN'&&target==='AWAKE'){rt.setMode('AWAKE');add('Restored from durable state. Stream may continue.')}else rt.setMode(target)});
$('#send').onclick=()=>{const text=input.value;if(!text.trim())return;haptic();const r=rt.ingestText(text,{boundary:true});if(r.accepted){add(text,'human',`HUMAN STREAM · ${r.event.sourceId} · ${r.event.cursorEnd}`);input.value='';input.style.height='42px';add('Boundary received as a hint; cognition is not reset.','system','STREAM') }};
input.addEventListener('input',()=>{input.style.height='42px';input.style.height=Math.min(input.scrollHeight,120)+'px'});
add('Runtime shell restored. This UI is a window into a continuous event stream, not a prompt/completion engine.');
const s=rt.snapshot();if(s.eventSeq)add(`Recovered durable state at event ${s.eventSeq}.`,'system','RESTORE');paint();
